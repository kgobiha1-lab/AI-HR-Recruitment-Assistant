"""
memory.py
---------
Simple persistent memory for the agent. Keeps track of every candidate
processed in the session (and across runs, via a JSON file on disk) so the
agent can answer questions like "who did we screen for this role?" or avoid
re-processing the same resume twice.
"""

import json
import os
from datetime import datetime


class AgentMemory:
    def __init__(self, memory_path):
        self.memory_path = memory_path
        self.records = self._load()

    def _load(self):
        if os.path.exists(self.memory_path):
            with open(self.memory_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return []

    def save(self):
        os.makedirs(os.path.dirname(self.memory_path), exist_ok=True)
        with open(self.memory_path, "w", encoding="utf-8") as f:
            json.dump(self.records, f, indent=2)

    def add_record(self, match_result):
        record = dict(match_result)
        record["timestamp"] = datetime.now().isoformat(timespec="seconds")
        self.records.append(record)
        self.save()

    def get_history_for_job(self, job_title):
        return [r for r in self.records if r["job_title"].lower() == job_title.lower()]

    def get_top_candidates(self, job_title, top_n=3):
        history = self.get_history_for_job(job_title)
        return sorted(history, key=lambda r: r["total_score"], reverse=True)[:top_n]

    def all_records(self):
        return self.records

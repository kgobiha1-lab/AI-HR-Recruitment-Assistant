"""
recruitment_agent.py
---------------------
The Agent. Orchestrates:
  - RAG          -> retrieves the most relevant job description(s)
  - Tools        -> parse_resume, calculate_match_score, generate_interview_questions
  - Memory       -> stores every screening result for later lookup

This is the "brain" that decides which tool to call and in what order,
similar to how a tool-calling LLM agent reasons step by step.
"""

from . import tools
from .rag import RAGKnowledgeBase
from .memory import AgentMemory


class HRRecruitmentAgent:
    def __init__(self, jd_path, memory_path, policy_text=None):
        self.kb = RAGKnowledgeBase(jd_path, policy_text=policy_text)
        self.memory = AgentMemory(memory_path)

    # ---------- Step 1: RAG ----------
    def find_best_job_match(self, resume_text):
        """Use RAG to retrieve the most relevant job description for a resume."""
        results = self.kb.retrieve(resume_text, top_k=1, doc_type="job_description")
        if not results:
            return None
        return results[0]

    # ---------- Full agent pipeline for ONE resume ----------
    def screen_candidate(self, resume_text, filename=None, job_title=None):
        """
        Full agent pipeline:
          1. Parse resume (tool)
          2. Retrieve matching job via RAG (or use specified job_title)
          3. Score candidate against job (tool)
          4. Generate interview questions (tool)
          5. Store result in memory
        """
        candidate = tools.parse_resume(resume_text, filename=filename)

        if job_title:
            job_doc = self.kb.get_job_by_title(job_title)
        else:
            job_doc = self.find_best_job_match(resume_text)

        if job_doc is None:
            raise ValueError("No matching job description found in the knowledge base.")

        job_meta = job_doc["meta"]
        match_result = tools.calculate_match_score(candidate, job_meta)
        questions = tools.generate_interview_questions(match_result)
        match_result["interview_questions"] = questions
        match_result["matched_job_via"] = "RAG retrieval" if not job_title else "user-specified"

        self.memory.add_record(match_result)
        return match_result

    # ---------- Batch processing across many resumes ----------
    def screen_batch(self, resume_dict, job_title=None):
        """resume_dict: {filename: resume_text}. Returns list of results, ranked."""
        results = []
        for filename, text in resume_dict.items():
            result = self.screen_candidate(text, filename=filename, job_title=job_title)
            results.append(result)
        results.sort(key=lambda r: r["total_score"], reverse=True)
        return results

    def get_ranked_shortlist(self, job_title, top_n=3):
        """Query memory (agent's long-term knowledge) for the best candidates so far."""
        return self.memory.get_top_candidates(job_title, top_n=top_n)

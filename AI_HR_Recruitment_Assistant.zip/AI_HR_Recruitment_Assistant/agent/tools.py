"""
tools.py
--------
"Tools" the agent can call. Each tool does one focused job, mirroring how a
real tool-calling LLM agent would be wired up (function -> schema -> call).

Tools implemented:
  1. parse_resume        -> extract candidate name, email, phone, skills, experience
  2. extract_skills       -> pull skill keywords from any text
  3. calculate_match_score-> score a candidate against a job description
  4. generate_interview_questions -> produce tailored interview questions
"""

import re

# A reasonably broad skills vocabulary used for keyword extraction.
SKILL_VOCAB = [
    "python", "java", "c++", "c#", "javascript", "typescript", "sql", "nosql",
    "mongodb", "postgresql", "mysql", "react", "angular", "vue", "node.js",
    "django", "flask", "fastapi", "aws", "azure", "gcp", "docker", "kubernetes",
    "git", "linux", "machine learning", "deep learning", "nlp", "computer vision",
    "tensorflow", "pytorch", "pandas", "numpy", "scikit-learn", "data analysis",
    "data engineering", "etl", "spark", "hadoop", "excel", "power bi", "tableau",
    "communication", "leadership", "project management", "agile", "scrum",
    "recruitment", "talent acquisition", "hr operations", "payroll",
    "rest api", "microservices", "ci/cd", "testing", "automation", "selenium"
]


def extract_skills(text):
    """Extract known skills mentioned in a block of text."""
    text_lower = text.lower()
    found = []
    for skill in SKILL_VOCAB:
        if skill in text_lower:
            found.append(skill)
    return sorted(set(found))


def extract_experience_years(text):
    """Find the maximum number of years of experience mentioned in text."""
    matches = re.findall(r"(\d+(?:\.\d+)?)\s*\+?\s*(?:years|yrs)", text.lower())
    years = [float(m) for m in matches]
    return max(years) if years else 0


def extract_contact_info(text):
    email_match = re.search(r"[\w\.-]+@[\w\.-]+\.\w+", text)
    phone_match = re.search(r"(\+?\d[\d\-\s]{8,14}\d)", text)
    return {
        "email": email_match.group(0) if email_match else "Not found",
        "phone": phone_match.group(0).strip() if phone_match else "Not found"
    }


def extract_name(text, filename=None):
    """Very light heuristic: first non-empty line is usually the candidate's name."""
    for line in text.strip().splitlines():
        line = line.strip()
        if line and len(line.split()) <= 4 and not any(ch.isdigit() for ch in line):
            return line
    if filename:
        return filename.replace("_", " ").replace(".txt", "").title()
    return "Unknown Candidate"


def parse_resume(resume_text, filename=None):
    """Tool: parse a raw resume text into structured candidate data."""
    return {
        "name": extract_name(resume_text, filename),
        "contact": extract_contact_info(resume_text),
        "skills": extract_skills(resume_text),
        "experience_years": extract_experience_years(resume_text),
        "raw_text": resume_text
    }


def calculate_match_score(candidate, job_meta):
    """
    Tool: score a parsed candidate against a job's requirements.
    Returns a dict with overall score (0-100) and a breakdown.
    """
    required = set(s.lower() for s in job_meta.get("required_skills", []))
    preferred = set(s.lower() for s in job_meta.get("preferred_skills", []))
    candidate_skills = set(candidate["skills"])

    matched_required = required & candidate_skills
    matched_preferred = preferred & candidate_skills
    missing_required = required - candidate_skills

    # Weighted scoring: required skills matter most, then experience, then preferred
    required_score = (len(matched_required) / len(required) * 60) if required else 60
    preferred_score = (len(matched_preferred) / len(preferred) * 15) if preferred else 15

    min_exp = job_meta.get("min_experience_years", 0)
    if min_exp == 0:
        experience_score = 25
    else:
        experience_score = min(candidate["experience_years"] / min_exp, 1.0) * 25

    total_score = round(required_score + preferred_score + experience_score, 1)

    if total_score >= 80:
        verdict = "Strong Match - Recommend for Interview"
    elif total_score >= 60:
        verdict = "Moderate Match - Consider for Interview"
    else:
        verdict = "Weak Match - Likely Not Suitable"

    return {
        "candidate_name": candidate["name"],
        "job_title": job_meta["title"],
        "total_score": total_score,
        "matched_required_skills": sorted(matched_required),
        "missing_required_skills": sorted(missing_required),
        "matched_preferred_skills": sorted(matched_preferred),
        "candidate_experience_years": candidate["experience_years"],
        "required_experience_years": min_exp,
        "verdict": verdict
    }


# Question banks used to generate tailored interview questions.
_TECHNICAL_TEMPLATES = {
    "python": "Can you walk us through a Python project where you had to optimize performance?",
    "java": "Describe a time you used Java to build a scalable backend service.",
    "sql": "How would you optimize a slow-running SQL query on a large table?",
    "machine learning": "Explain how you would approach a classification problem with imbalanced data.",
    "aws": "What AWS services have you used in production, and how did you ensure cost efficiency?",
    "docker": "How do you use Docker to ensure consistency across dev, staging, and production?",
    "react": "How do you manage state in a large-scale React application?",
    "project management": "Tell us about a project you managed that faced a major delay. How did you handle it?",
    "recruitment": "Walk us through your end-to-end recruitment process for a hard-to-fill role.",
}

_GENERIC_QUESTIONS = [
    "Tell us about yourself and why you're interested in this role.",
    "Describe a challenging problem you solved recently and your approach.",
    "How do you prioritize tasks when handling multiple deadlines?",
    "Tell us about a time you disagreed with a teammate. How did you resolve it?",
    "Where do you see yourself professionally in the next 2-3 years?",
]


def generate_interview_questions(match_result, num_questions=6):
    """
    Tool: generate interview questions tailored to the candidate's matched
    skills and any gaps found during scoring.
    """
    questions = []

    # Skill-specific technical questions based on what the candidate DOES have
    for skill in match_result["matched_required_skills"] + match_result["matched_preferred_skills"]:
        if skill in _TECHNICAL_TEMPLATES:
            questions.append(_TECHNICAL_TEMPLATES[skill])

    # Probe questions for missing required skills (to check adjacent/transferable knowledge)
    for skill in match_result["missing_required_skills"][:2]:
        questions.append(
            f"You don't have direct '{skill}' listed on your resume — "
            f"have you worked with anything similar, and how would you ramp up quickly?"
        )

    # Fill remaining slots with generic behavioral questions
    for q in _GENERIC_QUESTIONS:
        if len(questions) >= num_questions:
            break
        questions.append(q)

    # De-duplicate while preserving order, then trim to requested count
    seen = set()
    final_questions = []
    for q in questions:
        if q not in seen:
            seen.add(q)
            final_questions.append(q)
    return final_questions[:num_questions]

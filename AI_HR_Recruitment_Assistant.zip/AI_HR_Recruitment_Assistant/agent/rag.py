"""
rag.py
------
Retrieval-Augmented Generation (RAG) component for the AI HR Recruitment Assistant.

This module builds a small in-memory "knowledge base" out of:
  - Job Descriptions (JDs)
  - Company hiring policies / interview guidelines

It performs simple but effective keyword + TF-style retrieval so the agent
can pull the most relevant context before matching a resume or generating
interview questions. In a production system this would be replaced by a
vector database (e.g. FAISS / Chroma) + embeddings, but the retrieval
*pattern* (chunk -> score -> retrieve top-k -> feed to agent) is identical.
"""

import json
import os
import re
from collections import Counter


class RAGKnowledgeBase:
    def __init__(self, jd_path, policy_text=None):
        self.jd_path = jd_path
        self.documents = []  # list of dicts: {id, type, title, text}
        self._load_job_descriptions()
        if policy_text:
            self._add_document("policy", "Hiring Policy", policy_text)

    def _load_job_descriptions(self):
        with open(self.jd_path, "r", encoding="utf-8") as f:
            jobs = json.load(f)
        for job in jobs:
            full_text = (
                f"Title: {job['title']}\n"
                f"Department: {job['department']}\n"
                f"Required Skills: {', '.join(job['required_skills'])}\n"
                f"Preferred Skills: {', '.join(job.get('preferred_skills', []))}\n"
                f"Min Experience: {job['min_experience_years']} years\n"
                f"Description: {job['description']}"
            )
            self._add_document("job_description", job["title"], full_text, meta=job)

    def _add_document(self, doc_type, title, text, meta=None):
        self.documents.append({
            "id": len(self.documents),
            "type": doc_type,
            "title": title,
            "text": text,
            "meta": meta or {}
        })

    @staticmethod
    def _tokenize(text):
        return re.findall(r"[a-zA-Z0-9\+\#]+", text.lower())

    def _score(self, query_tokens, doc_tokens):
        """Simple term-overlap scoring (bag-of-words relevance)."""
        doc_counter = Counter(doc_tokens)
        score = 0
        for tok in query_tokens:
            score += doc_counter.get(tok, 0)
        # normalize a bit by document length so long docs don't always win
        return score / (len(doc_tokens) ** 0.3 + 1)

    def retrieve(self, query, top_k=3, doc_type=None):
        """Retrieve the top_k most relevant documents/chunks for a query."""
        query_tokens = self._tokenize(query)
        scored = []
        for doc in self.documents:
            if doc_type and doc["type"] != doc_type:
                continue
            doc_tokens = self._tokenize(doc["text"])
            s = self._score(query_tokens, doc_tokens)
            if s > 0:
                scored.append((s, doc))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [doc for _, doc in scored[:top_k]]

    def get_all_jobs(self):
        return [d for d in self.documents if d["type"] == "job_description"]

    def get_job_by_title(self, title):
        for d in self.documents:
            if d["type"] == "job_description" and d["title"].lower() == title.lower():
                return d
        return None

"""
main.py
-------
Entry point for the AI HR Recruitment Assistant.

Run this file to see the full agent pipeline in action:
  1. Load job descriptions into the RAG knowledge base.
  2. Load sample resumes.
  3. For each resume, the agent retrieves the best-fit job (RAG),
     scores the candidate (Tool), and generates tailored interview
     questions (Tool).
  4. Results are stored in memory and a ranked shortlist + a text
     report are produced.

Usage:
    python main.py
"""

import os
import json
from agent.recruitment_agent import HRRecruitmentAgent

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
JD_PATH = os.path.join(BASE_DIR, "data", "job_descriptions.json")
RESUME_DIR = os.path.join(BASE_DIR, "data", "resumes")
MEMORY_PATH = os.path.join(BASE_DIR, "output", "agent_memory.json")
REPORT_PATH = os.path.join(BASE_DIR, "output", "screening_report.txt")

HIRING_POLICY = (
    "All shortlisted candidates must have at least 1 verifiable reference. "
    "Interview panels must include one member from the hiring department "
    "and one from HR. Offers are extended within 5 business days of the "
    "final interview round."
)


def load_resumes(resume_dir):
    resumes = {}
    for filename in sorted(os.listdir(resume_dir)):
        if filename.endswith(".txt"):
            with open(os.path.join(resume_dir, filename), "r", encoding="utf-8") as f:
                resumes[filename] = f.read()
    return resumes


def print_divider(title=""):
    print("\n" + "=" * 70)
    if title:
        print(title)
        print("=" * 70)


def main():
    print_divider("AI HR RECRUITMENT ASSISTANT — Agent + Tools + RAG")

    # Reset memory for a clean demo run each time
    if os.path.exists(MEMORY_PATH):
        os.remove(MEMORY_PATH)

    agent = HRRecruitmentAgent(JD_PATH, MEMORY_PATH, policy_text=HIRING_POLICY)
    resumes = load_resumes(RESUME_DIR)

    print(f"\nLoaded {len(resumes)} resumes and "
          f"{len(agent.kb.get_all_jobs())} job descriptions into the knowledge base.\n")

    report_lines = []
    report_lines.append("AI HR RECRUITMENT ASSISTANT — SCREENING REPORT")
    report_lines.append("=" * 60)

    all_results = agent.screen_batch(resumes)  # RAG auto-picks best-fit job per resume

    for result in all_results:
        print_divider(f"Candidate: {result['candidate_name']}")
        print(f"Matched Job (via {result['matched_job_via']}): {result['job_title']}")
        print(f"Total Score: {result['total_score']} / 100")
        print(f"Verdict: {result['verdict']}")
        print(f"Matched Required Skills: {result['matched_required_skills']}")
        print(f"Missing Required Skills: {result['missing_required_skills']}")
        print(f"Experience: {result['candidate_experience_years']} yrs "
              f"(required: {result['required_experience_years']} yrs)")
        print("\nSuggested Interview Questions:")
        for i, q in enumerate(result["interview_questions"], 1):
            print(f"  {i}. {q}")

        report_lines.append(f"\nCandidate: {result['candidate_name']}")
        report_lines.append(f"Matched Job: {result['job_title']} (via {result['matched_job_via']})")
        report_lines.append(f"Score: {result['total_score']}/100  |  Verdict: {result['verdict']}")
        report_lines.append(f"Matched Required Skills: {', '.join(result['matched_required_skills']) or 'None'}")
        report_lines.append(f"Missing Required Skills: {', '.join(result['missing_required_skills']) or 'None'}")
        report_lines.append(f"Experience: {result['candidate_experience_years']} yrs "
                             f"(required {result['required_experience_years']} yrs)")
        report_lines.append("Interview Questions:")
        for i, q in enumerate(result["interview_questions"], 1):
            report_lines.append(f"  {i}. {q}")
        report_lines.append("-" * 60)

    # Demonstrate memory: ranked shortlist per job title touched in this run
    print_divider("RANKED SHORTLISTS (from Agent Memory)")
    report_lines.append("\n\nRANKED SHORTLISTS (from Agent Memory)")
    report_lines.append("=" * 60)

    job_titles_seen = sorted(set(r["job_title"] for r in all_results))
    for job_title in job_titles_seen:
        shortlist = agent.get_ranked_shortlist(job_title, top_n=3)
        print(f"\nTop candidates for '{job_title}':")
        report_lines.append(f"\nTop candidates for '{job_title}':")
        for rank, cand in enumerate(shortlist, 1):
            line = f"  {rank}. {cand['candidate_name']} — {cand['total_score']}/100 ({cand['verdict']})"
            print(line)
            report_lines.append(line)

    os.makedirs(os.path.dirname(REPORT_PATH), exist_ok=True)
    with open(REPORT_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(report_lines))

    print_divider()
    print(f"Full report saved to: {REPORT_PATH}")
    print(f"Agent memory saved to: {MEMORY_PATH}")


if __name__ == "__main__":
    main()

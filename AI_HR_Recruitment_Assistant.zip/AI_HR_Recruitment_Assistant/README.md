# AI HR Recruitment Assistant

**Use Case #2** — Screens resumes, matches candidates with job descriptions,
and generates interview questions.
**Key Agent Capabilities:** Agent + Tools + RAG

## What This Project Does

This project simulates an AI-powered recruitment assistant that a real HR
team could use to speed up first-round resume screening:

1. **RAG (Retrieval-Augmented Generation)** — A small knowledge base of job
   descriptions is built (`agent/rag.py`). For every resume, the agent
   retrieves the most relevant job description using keyword-overlap
   retrieval (the same pattern as embedding-based RAG, just without needing
   external vector DB dependencies).
2. **Tools** (`agent/tools.py`) — Modular functions the agent calls:
   - `parse_resume` — extracts name, contact info, skills, years of experience
   - `calculate_match_score` — scores the candidate against the job's
     required/preferred skills and experience requirement (0–100 scale)
   - `generate_interview_questions` — produces tailored technical + behavioral
     interview questions based on what matched and what's missing
3. **Memory** (`agent/memory.py`) — Every screening result is stored in
   `output/agent_memory.json`, so the agent can be queried later for a
   ranked shortlist of the best candidates for any given role.
4. **Agent orchestration** (`agent/recruitment_agent.py`) — Ties RAG, Tools,
   and Memory together into a single pipeline: `screen_candidate()` /
   `screen_batch()`.

## Project Structure

```
AI_HR_Recruitment_Assistant/
├── main.py                        # Run this to see the full demo
├── agent/
│   ├── rag.py                     # Knowledge base + retrieval
│   ├── tools.py                   # parse / score / question-generation tools
│   ├── memory.py                  # Persistent candidate history
│   └── recruitment_agent.py       # Orchestrates RAG + Tools + Memory
├── data/
│   ├── job_descriptions.json      # 5 sample job descriptions
│   └── resumes/                   # 3 sample candidate resumes (.txt)
└── output/                        # Generated report + memory (created on run)
```

## How to Run

Requires Python 3.8+ (standard library only — no external dependencies).

```bash
cd AI_HR_Recruitment_Assistant
python3 main.py
```

This will:
- Load all resumes in `data/resumes/`
- Match each one to the best-fit job description via RAG
- Score each candidate and print a verdict
- Generate custom interview questions per candidate
- Save a full report to `output/screening_report.txt`
- Save agent memory to `output/agent_memory.json`
- Print a ranked shortlist per job role

## Testing With Your Own Resumes

Drop any `.txt` resume file into `data/resumes/` and re-run `main.py` —
no code changes needed. You can also add more roles to
`data/job_descriptions.json` following the existing format.

## Example Output (abridged)

```
Candidate: Arjun Kumar
Matched Job (via RAG retrieval): Backend Python Developer
Total Score: 100.0 / 100
Verdict: Strong Match - Recommend for Interview
Matched Required Skills: ['git', 'python', 'rest api', 'sql']

Suggested Interview Questions:
  1. Can you walk us through a Python project where you had to optimize performance?
  2. How would you optimize a slow-running SQL query on a large table?
  ...
```

## Possible Extensions
- Swap the keyword-based RAG retrieval for real embeddings (e.g. sentence-transformers + FAISS)
- Parse PDF/DOCX resumes directly instead of plain text
- Add a Streamlit/Flask front-end for HR staff to upload resumes interactively
- Connect `generate_interview_questions` to an LLM API for richer, more natural questions
